# AI-native PaaS — доменный roadmap и TDD-план

## Реализовано сейчас: итерации 1–4

Текущий cumulative repository закрывает четыре bounded context:

```text
Platform Kernel
    ↓
Source Control
    ↓
Build & Artifact Supply Chain
    ↓
Runtime Delivery
```

### Iteration 4 — Runtime Delivery

Реализован путь от immutable `ArtifactRef` до runtime release:

- приложения, environments, runtime cells и sticky placement;
- exact-digest releases, deployments и auditable rollback;
- deterministic GitOps renderer и recovery после окна Git/DB failure;
- restricted Argo CD ApplicationSet/AppProject contracts;
- `PaaSApp v1alpha1` CRD;
- PaaS operator с migration/readiness/traffic-switch lifecycle;
- gVisor/restricted pod defaults на уровне generated object model;
- HPA/controller ownership, drift repair, suspension и two-phase deletion;
- hardened status trust boundary;
- PostgreSQL schema `runtime` с optimistic locking, append-only records и payload-consistency triggers;
- development HTTP API, raw Kubernetes REST adapter и runnable operator binary;
- no-Kubernetes end-to-end acceptance, race, fuzz, process smoke и live PostgreSQL tests.

Проверка без live Kubernetes:

```bash
./scripts/verify-iteration-4.sh
```

При внешнем PostgreSQL:

```bash
export TEST_POSTGRES_DSN='host=127.0.0.1 port=5432 user=postgres password=postgres dbname=paas_test sslmode=disable'
REQUIRE_POSTGRES=1 ./scripts/verify-iteration-4.sh
```

Документы:

- [final status](docs/iteration-4/FINAL_STATUS.md);
- [implementation](docs/iteration-4/IMPLEMENTATION.md);
- [decisions](docs/iteration-4/DECISIONS.md);
- [threat model](docs/iteration-4/THREAT_MODEL.md);
- [test report](docs/iteration-4/TEST_REPORT.md);
- [non-Kubernetes TODO](docs/iteration-4/TODO.md);
- [Kubernetes-only acceptance TODO](docs/iteration-4/KUBERNETES_TODO.md);
- [handoff to Iteration 5](docs/iteration-4/HANDOFF.md).

Current verdict:

```text
Iteration 4 domain/runtime gates: GREEN
Live PostgreSQL:                 GREEN
Live Kubernetes:                 NOT RUN / explicit separate gate
```

### Previous iterations

- все пять отложенных live PostgreSQL tests Iteration 1 прошли на PostgreSQL 18.4;
- Source Control defects, обнаруженные при интеграции, исправлены как Iteration 2 follow-up;
- Iteration 3 Build & Artifact trust chain остаётся frozen input для Runtime Delivery;
- следующие домены не импортируют internal packages или SQL schemas предыдущих итераций.

> `cmd/kernel-api`, `cmd/source-api`, `cmd/build-api` и `cmd/runtime-api` являются local/development harness. `cmd/runtime-operator` компилируется и проверен через narrow client contracts, но его live-cluster acceptance вынесен в отдельный Kubernetes gate.

## Цель

Построить control plane публичного AI-native PaaS последовательными bounded contexts. Каждая итерация должна:

1. владеть своим состоянием и схемой данных;
2. зависеть только от опубликованных контрактов предыдущих итераций;
3. завершаться работающим acceptance-сценарием;
4. оставлять неизменяемый контракт для следующей итерации;
5. начинаться с тестов, а не с реализации.

Основной стек, заложенный в план:

- Go modular monolith для control plane;
- PostgreSQL;
- GitLab Self-Managed;
- kpack / Cloud Native Buildpacks;
- Harbor;
- GitOps repository;
- Argo CD;
- собственный `PaaSApp` operator;
- Cozystack;
- OpenBao + External Secrets;
- Kubernetes runtime cells с gVisor/Cilium.

## Последовательность из семи итераций

### Итерация 1 — Platform Kernel

Identity references, organizations, memberships, authorization, idempotency, asynchronous operations, transactional outbox/inbox и audit.

Экспортирует стабильные контракты:

- `PrincipalContext`;
- `TenantRef`;
- `OperationRef`;
- `AuditEnvelope`;
- `DomainEventEnvelope`.

Документ: `docs/tdd/01-platform-kernel.md`.

### Итерация 2 — Source Control

Projects, repositories, GitLab provisioning, branch policy, agent workspace, commits, webhooks и source reconciliation.

Экспортирует:

- `ProjectRef`;
- `RepositoryRef`;
- `SourceRevision`;
- события `source.commit_observed.v1` и `source.merge_request_changed.v1`.

Документ: `docs/tdd/02-source-control.md`.

### Итерация 3 — Build & Artifact Supply Chain

Build request, runtime detection, buildpacks, Dockerfile fallback, build state machine, registry, SBOM, scan, signing и immutable artifact metadata.

Экспортирует:

- `BuildRef`;
- `ArtifactRef`;
- `ReleasabilityDecision`;
- события `build.completed.v1` и `artifact.releasable.v1`.

Документ: `docs/tdd/03-build-and-artifact.md`.

### Итерация 4 — Runtime Delivery

Applications, environments, releases, runtime cells, placement, GitOps rendering, Argo CD delivery и `PaaSApp` operator.

Экспортирует:

- `ApplicationRef`;
- `EnvironmentRef`;
- `ReleaseRef`;
- `DeploymentRef`;
- `RuntimeStatus`.

Документ: `docs/tdd/04-runtime-delivery.md`.

### Итерация 5 — Application Attachments

Secrets, managed services, service bindings, generated domains, custom domains, ownership verification и TLS lifecycle.

Экспортирует:

- `SecretSetRef`;
- `ServiceInstanceRef`;
- `ServiceBindingRef`;
- `DomainClaimRef`;
- `AttachmentSnapshot`.

Документ: `docs/tdd/05-application-attachments.md`.

### Итерация 6 — Commercial Governance

Plans, plan versions, units, entitlements, quotas, usage ledger, rating, invoice preview, suspension и resumption.

Экспортирует:

- `EntitlementDecision`;
- `QuotaReservation`;
- `UsageEvent`;
- `RatedUsage`;
- `CommercialState`.

Документ: `docs/tdd/06-commercial-governance.md`.

### Итерация 7 — Agent Governance & Public API

MCP/API façade, agent principals, approvals, budgets, repair-loop controls, destructive-operation gates и end-to-end orchestration.

Экспортирует публичную API/MCP contract surface продукта.

Документ: `docs/tdd/07-agent-governance.md`.

## Почему итерации почти не пересекаются

Цепочка зависимостей однонаправленная:

```text
Platform Kernel
    ↓
Source Control
    ↓
Build & Artifact
    ↓
Runtime Delivery
    ↓
Application Attachments
    ↓
Commercial Governance
    ↓
Agent Governance
```

Поздний домен не читает таблицы раннего домена напрямую. Он получает данные через:

- versioned Go interfaces;
- versioned HTTP/internal RPC contracts;
- versioned domain events;
- read models, принадлежащие потребителю.

Каждый bounded context имеет отдельную PostgreSQL schema:

```text
kernel
source
build
runtime
attachments
commerce
agent
```

Между schemas нет cross-domain foreign keys. Внешние идентификаторы хранятся как value objects. Это позволяет менять внутреннюю модель домена без каскадных миграций.

## Правило заморозки контракта

После завершения итерации:

- публичные типы получают версию;
- события получают suffix `.v1`;
- consumer contract tests становятся merge gate;
- breaking change требует нового контракта `.v2`;
- следующая итерация не импортирует внутренние packages предыдущей;
- разрешены только additive изменения и исправления дефектов.

## Базовая структура репозитория

```text
/cmd
  /api
  /worker
  /operator
  /cell-agent
/internal
  /kernel
  /source
  /build
  /runtime
  /attachments
  /commerce
  /agent
/contracts
  /events
  /http
  /mcp
/adapters
  /postgres
  /gitlab
  /kpack
  /harbor
  /argocd
  /cozystack
  /openbao
  /dns
/test
  /fixtures
  /contract
  /integration
  /acceptance
  /security
  /chaos
/docs
  /tdd
  /adr
```

## Общая TDD-дисциплина

Каждый use case проходит один и тот же цикл:

1. Написать один red-тест на observable behavior.
2. Добавить минимальную реализацию.
3. Сделать тест green.
4. Добавить negative/concurrency test.
5. Рефакторить только после green.
6. Добавить contract/integration test для внешнего адаптера.
7. Закрыть acceptance-сценарием через публичный API.

### Уровни тестирования

#### 1. Domain tests

Чистые Go-тесты без сети, файловой системы, БД и Kubernetes. Проверяют invariants и state machines.

#### 2. Application tests

Use cases с in-memory ports/fakes. Проверяют authorization, orchestration, idempotency, retries и emitted events.

#### 3. Contract tests

Проверяют стабильность:

- event schemas;
- HTTP/MCP schemas;
- GitLab/kpack/Harbor/Argo/Cozystack/OpenBao adapter expectations;
- CRD OpenAPI schema.

#### 4. Adapter integration tests

Реальные PostgreSQL transactions, HTTP stub servers, local OCI registry, Kubernetes `envtest` и `kind`.

#### 5. Acceptance tests

Через публичный API. Не используют внутренние packages и не проверяют private implementation details.

#### 6. Security/chaos tests

Запускаются отдельно, но являются обязательным release gate перед public beta.

## Общие тестовые правила

- Все mutation endpoints принимают `Idempotency-Key`.
- Все события имеют `event_id`, `correlation_id`, `causation_id`, `tenant_id`, `aggregate_id`, `occurred_at`, `type`, `version`.
- Время инъецируется через `Clock`.
- UUID/ULID инъецируется через `IDGenerator`.
- Случайность инъецируется через `RandomSource`.
- Никакого `time.Sleep` в unit/integration tests.
- Retry/backoff проверяется virtual clock.
- Каждая внешняя операция имеет timeout, retry policy и idempotency semantics.
- Логи в тестах проходят secret-redaction assertion.
- SQL migrations тестируются на clean install и upgrade path.
- Property-based tests используются для state machines, rating и idempotency.

## Merge gates

Для каждой итерации обязательны:

```text
go test ./internal/<domain>/...
go test ./test/contract/...
go test ./test/integration/<domain>/...
go test ./test/acceptance/<domain>/...
```

Для operator/runtime дополнительно:

```text
go test ./internal/runtime/operator/... -tags=envtest
./scripts/test-kind-runtime.sh
```

## Definition of Done итерации

Итерация считается закрытой, когда:

- все перечисленные domain/application tests green;
- contract tests опубликованы;
- adapter integration tests green;
- минимум один acceptance-сценарий проходит через публичный API;
- schema migration имеет upgrade/rollback test;
- metrics, audit и structured errors добавлены;
- threat model домена обновлён;
- нет прямого импорта private package другого bounded context;
- следующий домен может использовать только зафиксированные контракты.

## Документ с общими контрактами и harness

Перед началом первой итерации прочитать и зафиксировать:

`docs/tdd/00-contracts-and-test-harness.md`.
<!-- ITERATION-5-STATUS -->

## Iteration 5 — Application Attachments

Status: **RED**

This snapshot adds secrets metadata, managed-service provisioning and bindings, domain/TLS lifecycle, immutable attachment snapshots and the Runtime Delivery bridge. See [`docs/iteration-5/FINAL_STATUS.md`](docs/iteration-5/FINAL_STATUS.md) for the evidence-based verdict and [`docs/iteration-5/TODO.md`](docs/iteration-5/TODO.md) for all unverified external-provider work.

